<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '5Ev&`XVuDI;2.SWK`Y;m=f: }Szl{RkAu+,-)Y9h3){g/^HVqM4?w{t^fCzwg.sQ' );

define( 'SECURE_AUTH_KEY',  'BG7p6*{PE;%,L=GuSI#x*lQs]YB_7+~f2 ZC)`$SbU_>`Ito!q9XuuBcd5t=c2$+' );

define( 'LOGGED_IN_KEY',    'Mv4/@0Zl2*6${nG3D!yZ{v%*)s>&;(=*;Le)B?K NuGW)YDXxS)m!-,y90_E/SNo' );

define( 'NONCE_KEY',        'CTMiY-rQvK7?7FNM=Zs*Y}q6qs4:uyGqu0-]:`EK!jc^is5hxe_zW2:qM&?G;|GF' );

define( 'AUTH_SALT',        'qF%o{5$I:%j.$>%q:jmK-c;5 &;u?fzU$(5TvvXWX!#D1bqRwlcQM6 qPZzrSJKa' );

define( 'SECURE_AUTH_SALT', 'aOM3IPf*n6f7l^y ti5y0BDaGt%DaM3F5!x2EU{!J^e{!rexG.^k^1MrPw8v< 5`' );

define( 'LOGGED_IN_SALT',   'T%zt[WMi! 5t|dO`li#l>J>tMB01plD?)VZfGvnj;P}|Sf!gL_ztkst1.jd!0{Ag' );

define( 'NONCE_SALT',       '!D`bs,x}az2u`Z9PF4:Hxba6/#f9xAo/@1w ,w)?p6m#jPI9gOEH>&u9f!b}o#v#' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

